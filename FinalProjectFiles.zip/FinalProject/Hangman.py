import random

class HangMan(object):
    hang = []
    hang.append(' +---+')
    hang.append(' |   |')
    hang.append('     |')
    hang.append('     |')
    hang.append('     |')
    hang.append('     |')
    hang.append('=======')
    
    man = {}
    man[0] = [' 0   |']
    man[1] = [' 0   |', ' |   |']
    man[2] = [' 0   |', '/|   |']
    man[3] = [' 0   |', '/|\\  |']
    man[4] = [' 0   |', '/|\\  |', '/    |']
    man[5] = [' 0   |', '/|\\  |', '/ \\  |']
    
    pics = []
  
    def __init__(self, *args, **kwargs):
        i, j = 2, 0
        self.pics.append(self.hang[:])
        for ls in self.man.values():
            pic, j = self.hang[:], 0
            for m in ls:
                pic[i + j] = m
                j += 1
            self.pics.append(pic)

    def pickWord(self):
        with open("words.txt", mode="r") as file:
            all_text = file.read()
            words = list(map(str, all_text.split()))
            return random.choice(words)
    
    def printPic(self, idx, wordLen):
        for line in self.pics[idx]:
            print(line)
            
    def askAndEvaluate(self, word, result, missed):
        guess = str(input())
        if guess == "1":
            return "Hint", True
        if guess == None or len(guess) != 1 or (guess in result) or (guess in missed):
            return None, False
        i = 0
        right = guess in word
        for c in word:
            if c == guess:
                result[i] = c
            i += 1
        return guess, right

    def info(self, info):
        print(info)
            
    def start(self):
        print('Welcome to Hangman! Enter the number 1 if you want a hint!')
        word = list(self.pickWord())
        result = list('*' * len(word))
        print('The word is: ', result)
        success, i, missed = False, 0, []
        while i < len(self.pics)-1:
            print('Guess the word: ', end='')
            guess,right = self.askAndEvaluate(word, result, missed)
            if guess == "Hint":
                counter = 0 
                while counter == 0:
                    random_number = random.randint(0, len(word) - 1)
                    random_letter = word[random_number]
                    if not random_letter in result:
                        counter = 1
                        print("Here's your hint!, A letter in the word is", random_letter)
                        continue
            if guess == None:
                print('You\'ve already entered this character.')
                continue
            print(''.join(result))
            if result == word:
                self.info('Congratulations! You\'ve just saved a life!')
                success = True
                break
            if not right:
                missed.append(guess)
                i+=1
            self.printPic(i, len(word))
            print('Incorrect Letters:', missed)
        
        if not success:
            self.info('The word was \''+''.join(word)+'\'! You lost!')

a = HangMan().start()